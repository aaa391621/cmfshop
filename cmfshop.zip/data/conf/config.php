<?php	return array (
  'cmf_default_theme' => 'simpleboot3',
);