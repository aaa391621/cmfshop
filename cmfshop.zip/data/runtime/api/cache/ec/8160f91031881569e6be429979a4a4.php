<?php
//000000000000
 exit();?>
s:113:"D:\php\VC98\phpEnv\www\thinkcmfShop\public\api/../../data/runtime/api/cache\2a\3eff9a760062733a1a46cf31ea8827.php";