<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:47:"themes/admin_simpleboot3/goods\order\index.html";i:1538366557;s:86:"D:\php\VC98\phpEnv\www\thinkcmfShop\public\themes\admin_simpleboot3\public\header.html";i:1535858921;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <!-- Set render engine for 360 browser -->
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- HTML5 shim for IE8 support of HTML5 elements -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <![endif]-->


    <link href="/themes/admin_simpleboot3/public/assets/themes/<?php echo cmf_get_admin_style(); ?>/bootstrap.min.css" rel="stylesheet">
    <link href="/themes/admin_simpleboot3/public/assets/simpleboot3/css/simplebootadmin.css" rel="stylesheet">
    <link href="/static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
    <script src="https://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style>
        form .input-order {
            margin-bottom: 0px;
            padding: 0 2px;
            width: 42px;
            font-size: 12px;
        }

        form .input-order:focus {
            outline: none;
        }

        .table-actions {
            margin-top: 5px;
            margin-bottom: 5px;
            padding: 0px;
        }

        .table-list {
            margin-bottom: 0px;
        }

        .form-required {
            color: red;
        }
    </style>
    <script type="text/javascript">
        //全局变量
        var GV = {
            ROOT: "/",
            WEB_ROOT: "/",
            JS_ROOT: "static/js/",
            APP: '<?php echo \think\Request::instance()->module(); ?>'/*当前应用名*/
        };
    </script>
    <script src="/themes/admin_simpleboot3/public/assets/js/jquery-1.10.2.min.js"></script>
    <script src="/static/js/wind.js"></script>
    <script src="/themes/admin_simpleboot3/public/assets/js/bootstrap.min.js"></script>
    <script>
        Wind.css('artDialog');
        Wind.css('layer');
        $(function () {
            $("[data-toggle='tooltip']").tooltip({
                container:'body',
                html:true,
            });
            $("li.dropdown").hover(function () {
                $(this).addClass("open");
            }, function () {
                $(this).removeClass("open");
            });
        });
    </script>
    <?php if(APP_DEBUG): ?>
        <style>
            #think_page_trace_open {
                z-index: 9999;
            }
        </style>
    <?php endif; ?>
</head>
<style>
    li {list-style-type:none;}
</style>
<body>
<div class="wrap js-check-wrap">
    <ul class="nav nav-tabs">
        <li class="active"><a href="javascript:;">所有订单</a></li>
    </ul>
    <form class="well form-inline margin-top-20" method="post" action="<?php echo url('Order/index'); ?>">
        状态:
        <select class="form-control" name="status" style="width: 140px;">
            <option value=''>全部</option>
            <option <?php if($status==1) echo("selected");?> value='1'>待付款</option>
            <option <?php if($status==2) echo("selected");?> value='2'>已完成</option>
            <option <?php if($status==3) echo("selected");?> value='3'>待发货</option>
            <option <?php if($status==4) echo("selected");?> value='4'>待收货</option>
            <option <?php if($status==5) echo("selected");?> value='5'>已取消</option>
        </select> &nbsp;&nbsp;
        时间:
        <input type="text" class="form-control js-bootstrap-datetime" name="start_time"
               value="<?php echo (isset($start_time) && ($start_time !== '')?$start_time:''); ?>"
               style="width: 140px;" autocomplete="off">-
        <input type="text" class="form-control js-bootstrap-datetime" name="end_time"
               value="<?php echo (isset($end_time) && ($end_time !== '')?$end_time:''); ?>"
               style="width: 140px;" autocomplete="off"> &nbsp; &nbsp;
        订单号:
        <input type="text" class="form-control" name="keyword" style="width: 200px;"
               value="<?php echo (isset($keyword) && ($keyword !== '')?$keyword:''); ?>" placeholder="请输入订单号...">
        <input type="submit" class="btn btn-primary" value="搜索"/>
        <a class="btn btn-danger" href="<?php echo url('Order/index'); ?>">清空</a>
    </form>
    <form class="js-ajax-form" action="" method="post">
        <table class="table table-hover table-bordered table-list">
            <thead>
            <tr>
                <th width="50">ID</th>
                <th>订单号</th>
                <th>支付订单</th>
                <th width="">用户名</th>
                <th width="">订单状态</th>
                <th width="">收货人</th>
                <th width="">地址</th>
                <th width="">手机</th>
                <th width="">订单总价</th>
                <th width="">下单时间</th>
                <th width="150">操作</th>
            </tr>
            </thead>
            <?php if(is_array($order) || $order instanceof \think\Collection || $order instanceof \think\Paginator): if( count($order)==0 ) : echo "" ;else: foreach($order as $key=>$vo): ?>
                <tr>
                    <td><b><?php echo $vo['id']; ?></b></td>
                    <td><?php echo $vo['order_sn']; ?></td>
                    <td><?php echo $vo['order_sn_submit']; ?></td>
                    <td><?php echo $vo['user_nickname']; ?></td>
                    <td id='order_status_<?php echo $vo['id']; ?>'>
                        <?php switch($vo['order_status']): case "1": ?><text style="color: orange">待付款</text><?php break; case "2": ?><text style="color: green">已完成</text><?php break; case "3": ?><text style="color: orangered">待发货</text><?php break; case "4": ?><text style="color: blueviolet">待收货</text><?php break; default: ?><text style="color: red">已取消</text>
                        <?php endswitch; ?>
                    </td>
                    <td><?php echo $vo['consignee']; ?></td>
                    <td><?php echo $vo['address']; ?></td>
                    <td><?php echo $vo['mobile']; ?></td>
                    <td><?php echo $vo['amount']; ?></td>
                    <td>
                        <?php echo $vo['submit_time']; ?>
                    </td>
                    <td>
                        <a id="<?php echo $vo['id']; ?>" href="javascript:"; onclick='detail(this)'>查看订单</a>
                        <a id="<?php echo $vo['id']; ?>" href="javascript:;" onclick='change(this)'>修改状态</a>
                     </td>
                </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
            <tfoot>

        </table>
        <ul class="pagination"><?php echo (isset($page) && ($page !== '')?$page:''); ?></ul>
    </form>
</div>
<script src="/static/js/layer.min.js"></script>

<script src="/static/js/admin.js"></script>
<script type="text/javascript">
    function detail(obj){
        var Id = obj.id;
        openIframeLayer("<?php echo url('Order/orderGoods'); ?>?id=" + Id, '订单详情', {
            area: ['900px', '500px'],
            btn: ['确定', '取消']
        });
    }
    function change(e){
        var Id = e.id;
        $.ajax({
            type: 'POST',
            dataType: 'json',
            url:"<?php echo url('Order/changeOrderStatus'); ?>",
            data:{'id':Id},
            success: function(obj){
                if(obj.status == 200){
                    layer.open({
                        content: obj.msg,
                        btn:['确定'],
                        shade:0.1,
                        icon:1,
                        end:function(){
                            $('#order_status_'+Id).html(obj.order_status);
                        }
                    });
                }else{
                    layer.open({
                        content: obj.msg,
                        btn:['确定'],
                        shade:0.1,
                        icon:2
                    });
                }
            }
        });
    }
</script>
</body>
</html>