<?php
//000000000000
 exit();?>
s:102:"D:\php\VC98\phpEnv\www\thinkcmfShop\public/../data/runtime/cache\c3\0b008a754ac7f1eeef085057ee3106.php";