<?php
//000000000000
 exit();?>
a:2:{s:7:"default";a:7:{s:4:"name";s:7:"shopcmf";s:6:"app_id";s:18:"wx9bb62ff1aba9f7f6";s:10:"app_secret";s:32:"43ba699fa479f4c502e8bc055e5fefbf";s:10:"is_default";s:1:"1";s:7:"_plugin";s:5:"wxapp";s:11:"_controller";s:11:"admin_wxapp";s:7:"_action";s:7:"addpost";}s:6:"wxapps";a:1:{s:18:"wx9bb62ff1aba9f7f6";a:6:{s:4:"name";s:7:"shopcmf";s:6:"app_id";s:18:"wx9bb62ff1aba9f7f6";s:10:"app_secret";s:32:"43ba699fa479f4c502e8bc055e5fefbf";s:7:"_plugin";s:5:"wxapp";s:11:"_controller";s:11:"admin_wxapp";s:7:"_action";s:7:"addpost";}}}